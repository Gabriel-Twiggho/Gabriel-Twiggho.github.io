# Handoff: World Cup Dashboard — Knockout Stage Revamp

## Overview
This package upgrades the **Knockout** section of the World Cup 2026 dashboard
(`Gabriel-Twiggho.github.io/worldcup-dashboard`) and makes a few related changes:

1. **Symmetric converging bracket** — R32 → R16 → QF → SF fan in from both sides
   into a centre column (WORLD CUP '26 medallion + the Final + third-place match).
2. **Path-to-final highlighting** — clicking any tie lights the winner's full route
   to the final and dims everything else; a "Clear highlighted path" button appears.
   Hovering a tie previews the next fixture (via the `wcFlowFor` label on each card).
3. **Section reorder** — the Knockout section now sits **above** the Group stage
   (group stage is over), in both the page and the top nav.
4. **Eliminated teams greyed** — any group-stage team that did **not** advance to the
   knockout stage has its name muted. Driven by live data, so nothing greys until the
   bracket is actually drawn.
5. **Fit-to-width bracket** — the bracket auto-scales to the viewport (full-bleed, centred)
   so the whole thing is visible without a horizontal scrollbar; stacks vertically < 1000px.
6. **Stadium background video** behind the Knockout section.

## About the design files & this codebase — IMPORTANT
This is **not** a "recreate these HTML mocks in a framework" handoff. The design was built
**directly against the real app**. The app ships as a **pre-built, minified Vite/React bundle**
(`assets/index-4Rub2ShJ.js`) with **no source tree in the repo**. All UI changes are applied by a
**Node patch script** (`tools/patch_dashboard_bundle.mjs`) that does exact-string replacements on the
bundle, plus two hand-maintained stylesheets and a small vanilla JS file.

So there are two ways to consume this package (pick based on what the repo owner wants):

- **Path A — Apply the patch (recommended, matches current workflow).** Use the updated
  `patch_dashboard_bundle.mjs` + `dashboard-fixes.css` + `background-videos.*` + `index.html`
  included here. This is the fastest, lowest-risk path and is exactly how the repo already works.
- **Path B — Port to real source.** If/when the owner regenerates a proper React source tree,
  re-implement the knockout section as a real component using the spec below. The patch script's
  replacement strings are readable JSX-via-`X.jsx` and document the exact component behavior.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, interactions, and responsive behavior are all
specified. Recreate pixel-for-pixel if porting to source.

---

## Files in this bundle
Copy these over the matching paths in `worldcup-dashboard/` (paths are relative to that folder):

| File | What changed |
|---|---|
| `index.html` | Cache-busting `?v=ko4` on the bundle + changed stylesheets/JS |
| `assets/index-4Rub2ShJ.js` | The patched bundle (already contains all JS changes) |
| `assets/dashboard-fixes.css` | All knockout redesign CSS (appended after the original rules) |
| `assets/background-videos.js` | Adds a `bracket` video source |
| `assets/background-videos.css` | `.wc-motion-bg.is-bracket` opacity rule |
| `tools/patch_dashboard_bundle.mjs` | Source of truth — regenerates the bundle from a clean copy |

> **The bundle is derived, not source.** `assets/index-4Rub2ShJ.js` is what
> `patch_dashboard_bundle.mjs` produces from a pristine bundle. If you ever re-download a fresh
> bundle from the build, just run the patch script again — do not hand-edit the minified file.

## How to apply (Path A)
```bash
cd worldcup-dashboard
# 1. Drop the files from this bundle into place (they overwrite the current ones).
# 2. (Optional but recommended) regenerate the bundle from a clean copy:
node tools/patch_dashboard_bundle.mjs
# 3. Serve locally and verify:
python3 -m http.server 8080   # or any static server
# open http://localhost:8080
git add index.html assets/index-4Rub2ShJ.js assets/dashboard-fixes.css \
        assets/background-videos.js assets/background-videos.css tools/patch_dashboard_bundle.mjs
git commit -m "Knockout revamp: symmetric bracket, path highlight, reorder, grey eliminated, fit-to-width"
git push
```
The patch script is **idempotent** — each step early-returns if its result is already present,
so running it twice is safe.

---

## The knockout section (component `av`, tile `H_`)
All of the following lives in the `"knockout symmetric redesign"` and the six
`section order` / `nav order` / `groups` / `group card` / `bracket fit-scale` steps in
`tools/patch_dashboard_bundle.mjs`. Read those replacement strings for the exact JSX.

### Data model — the bracket tree (`WCKO`)
The bundle has no explicit parent→child tree, so one is embedded as a constant. Matches are keyed
by **stage abbreviation + date-sorted index** (`"R32:0"`, `"R16:3"`, …), which is stable and does
**not** depend on live match IDs.

```js
const WCKO = {
  next: { "R32:0":"R16:0", "R32:1":"R16:1", /* …all 30 edges… */ "SF:0":"F:0", "SF:1":"F:0" },
  layout: {
    R32:{ L:[0,3,1,4,11,10,9,7], R:[2,6,5,8,12,14,13,15] },
    R16:{ L:[0,1,4,5],           R:[2,3,7,6] },
    QF: { L:[0,1],               R:[2,3] },
    SF: { L:[0],                 R:[1] }
  }
};
```
- `next[key]` → the match a winner advances to.
- `layout[stage].L / .R` → which date-sorted indices sit on the left / right half, **top-to-bottom**.
- Helpers: `wcPath(key)` walks `next` to the final (the highlighted route); `wcFeed(key)` walks
  backwards (all feeder ties); `wcFlowFor(key)` produces the "Winner → Quarter-final 2" label.
- Matches are grouped by `stage` (`round-of-32`, `round-of-16`, `quarterfinals`, `semifinals`,
  `final`, `3rd-place-match`) and sorted by `dateUtc.localeCompare` — the same ordering the original
  bundle used, so indices line up with `WCKO`.

### Layout
- Root: `<section id="bracket">` → `.bracket-scroll` (fit-scale wrapper) → `.wc-ko` (flex row).
- Three flex children: `.wc-ko-side.left` (columns R32,R16,QF,SF), `.wc-ko-center`,
  `.wc-ko-side.right` (columns SF,QF,R16,R32 — reversed).
- Each `.wc-ko-col` is `display:flex; flex-direction:column; justify-content:space-around` with a
  sticky `<h4>` round label pill on top.
- Column widths: R32 196px, R16 176px, QF 166px, SF 158px, centre 236px. Gaps 22px.

### Tile (`H_`) — `.wc-ko-tile`
- Glass card: `background rgba(255,255,255,.045)`, `border 1px solid rgba(255,255,255,.09)`,
  `border-radius 14px`, `backdrop-filter blur(16px) saturate(1.25)`,
  `box-shadow inset 0 1px 0 rgba(255,255,255,.05), 0 8px 22px rgba(0,0,0,.3)`.
  `padding 11px 12px 10px`. Transition `all .28s cubic-bezier(.4,0,.2,1)`.
- Rows: `.wc-ko-when` (date/city, 9.5px 650 uppercase `#f5f5f766`); two `.wc-ko-team`
  (18px logo, name `em` 12.5px 600 `#f5f5f7cc`, score `b` tabular). `.win em` → `#fff`;
  `.tbd em` → `#f5f5f759`. Optional `.wc-ko-flow` (9.5px 600 `#f5f5f77a`).
  `.wc-ko-open` pill ("Match details ↗") — this is what opens the match modal, since the tile
  click is used for path highlighting.
- Inward connector stub via `::after` (22px, `rgba(245,245,247,.16)`); on left side points right,
  right side points left.

### Highlight states (accent `--wc-ko-accent: #5ad6ff`)
- Container gets `.has-focus` when a tie is selected.
- `.is-off` → opacity .3, `saturate(.45)` (dimmed).
- `.is-path` → cyan border `rgba(90,214,255,.5)`, bg `rgba(90,214,255,.07)`, glow.
- `.is-focus` → strong cyan border/glow, `translateY(-2px)`.
- `.is-hover` → border `rgba(255,255,255,.26)`.
- `.is-next` → dashed cyan (hover preview of the next match).
- `::after` connector turns cyan + glows on `.is-path` / `.is-focus`.

### Centre column (`.wc-ko-center`)
- `.wc-medallion` — 96px circle, `1px solid rgba(251,233,166,.35)`, inner ring `::after`,
  `animation wcChampGlow 6s infinite` (gold glow pulse). Contains `.wc-medallion-top`
  ("World Cup", 8px 700 .2em uppercase gold) and `.wc-medallion-year` ("'26", 22px 700, gold
  gradient text `linear-gradient(180deg,#fbe9a6,#d29a2a)` clipped).
- `.wc-ko-final-wrap` — "The Final · <date>" label + the Final tile (gold-tinted).
- `.wc-ko-third` — muted third-place tile.

### Clear button (`.wc-ko-clear`)
Pill, cyan (`rgba(90,214,255,.08)` bg, `.4` border), with an ✕ chip; calls `setFocus(null)`.

---

## Fit-to-width scaling (in `av`)
Refs `wrapRef` (`.bracket-scroll`) and `innerRef` (`.wc-ko`); state `dims = {s, h}`.
A `useLayoutEffect` (deps `[matches, focus]`) runs `fit()`, plus a 120ms timeout, a
`ResizeObserver` on the wrapper, and a window `resize` listener:

```js
function fit() {
  const w = wrapRef.current, inr = innerRef.current;
  if (!w || !inr) return;
  const cw = w.clientWidth, sw = inr.scrollWidth;
  if (!cw || !sw) return;
  let s = Math.min(1, cw / sw);
  if (s < 0.5) s = 0.5;                 // floor; below this the mobile stack takes over
  setDims(p => {                        // guard against render thrash
    const nh = inr.offsetHeight * s;
    return (Math.abs(p.s - s) < .002 && Math.abs(p.h - nh) < 1) ? p : { s, h: nh };
  });
}
```
Applied as: wrapper `style={{ height: dims.h+'px', overflow:'hidden' }}`,
inner `style={{ transform:'scale('+dims.s+')', transformOrigin:'center top' }}`.

**Full-bleed CSS** (so it uses the whole screen, not the narrow content column), in
`dashboard-fixes.css` under `@media (min-width:1001px)`:
```css
#bracket .bracket-scroll{
  width:94vw; max-width:94vw;
  margin-left:calc(50% - 47vw); margin-right:calc(50% - 47vw);
  display:flex; justify-content:center; align-items:flex-start;
  padding:10px 24px 8px;
}
.wc-ko{ flex:none; width:max-content; justify-content:center; }
```
Below 1000px, the `@media (max-width:1000px)` block stacks the two halves vertically
(`.wc-ko` column, `.wc-ko-side.right` reversed, centre `order:-1`).

---

## Section reorder
- **Render order** (App component): `av` (bracket) is rendered **before** `iv` (groups),
  and `iv` now also receives `matches`:
  `X.jsx(av,{matches,onOpenMatch}), X.jsx(iv,{groups,onOpenTeam,matches})`.
- **Nav order** (`Dv` array): `["scores","Scores"],["bracket","Bracket"],["groups","Groups"],["teams","Teams"],["players","Players"]`.

## Greying eliminated teams
In `iv` (groups section), an advancing set is computed from knockout matches only:
```js
const wcAdv = useMemo(() => {
  const s = new Set();
  (matches || []).forEach(m => {
    if ($_.indexOf(m.stage) < 0) return;          // knockout stages only
    [m.home, m.away].forEach(t => { if (t && t.placeholder === false && t.teamId) s.add(t.teamId); });
  });
  return s;
}, [matches]);
```
`$_` = `["round-of-32","round-of-16","quarterfinals","semifinals","final"]`.
The set is passed to each group card (`tv`), which adds `wc-elim` to a team row when
`wcAdv.size && !wcAdv.has(entry.teamId)`. Because it keys off `placeholder === false`, **nothing
greys during the group stage** (all knockout slots are placeholders until the draw is made).

```css
.group-card tr.wc-elim td.team,
.group-card tr.wc-elim .team { color: #f5f5f766; }   /* muted; see dashboard-fixes.css for exact rule */
```

## Background video
`background-videos.js` gains a `bracket` source:
```js
bracket: { tone: "bracket",
  poster: "./assets/videos/pixabay-stadium-aerial-208387.jpg",
  video:  "./assets/videos/pixabay-stadium-aerial-208387.mp4" }
```
and `background-videos.css` adds `.wc-motion-bg.is-bracket { opacity:.2 }`.
Keep the two video asset files in `assets/videos/`.

---

## Design tokens
- **Accent (knockout):** `#5ad6ff` (`--wc-ko-accent`). Soft `rgba(90,214,255,.07–.12)`,
  border `rgba(90,214,255,.4–.85)`, glow `rgba(90,214,255,.15–.3)`.
- **Gold (medallion / Final):** gradient `linear-gradient(180deg,#fbe9a6,#d29a2a)`;
  borders `rgba(251,233,166,.26–.35)`; glow `rgba(246,216,121,.16–.3)`.
- **Ink:** `#f5f5f7` with alpha suffixes (`cc`,`99`,`7a`,`66`,`59`) for hierarchy.
- **Surfaces:** `rgba(255,255,255,.035–.08)`; hairline borders `rgba(255,255,255,.09–.26)`.
- **Radius:** tiles 14px, medallion 50%, pills 999px.
- **Type:** display `var(--display)` = Inter Tight (500–700); body Inter. Bracket labels
  9–12.5px; medallion year 22px.
- **Motion:** tiles `all .28s cubic-bezier(.4,0,.2,1)`; `wcChampGlow` 6s ease-in-out infinite.

## Assets
- `assets/videos/pixabay-stadium-aerial-208387.mp4` + `.jpg` (Pixabay stadium aerial; poster is the jpg).
- Team logos come from live data (`home.logo` / `away.logo`, ESPN country crests) — no new image assets.

## Interactions summary
- **Click a tie** → toggle `focus`; lights `wcPath` + dims `is-off`; shows clear button.
- **Click "Match details ↗"** (`.wc-ko-open`) → opens the existing match modal (`onOpenMatch(id)`).
- **Hover a tie** → sets `hover`; the tie gets `.is-hover`, its `next` gets `.is-next`.
- **Resize** → `fit()` re-scales the bracket to the viewport.
- Everything survives the app's 60s live-data refetch (the components are re-rendered with fresh
  data each poll; state is component-local).

## Verify checklist
- Knockout appears above Groups; nav reads Scores · Bracket · Groups · Teams · Players.
- Bracket fills the screen width, centred, no bottom scrollbar (desktop); stacks on mobile.
- Clicking a R32 tie lights exactly 5 tiles (R32→R16→QF→SF→Final) and dims the rest.
- Once the bracket is drawn with real teams, eliminated group teams show muted names;
  during the group stage nothing is greyed.
- No console errors.
